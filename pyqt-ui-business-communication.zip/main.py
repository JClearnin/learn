import sys
import queue
from PyQt5.QtWidgets import QApplication
from business_logic import BusinessLogic
from ui_app import UIApp

def main():
    # 创建应用实例
    app = QApplication(sys.argv)
    
    # 创建通信队列
    comm_queue = queue.Queue()
    
    # 初始化业务逻辑
    business = BusinessLogic(comm_queue)
    
    # 初始化UI应用
    window = UIApp(comm_queue, business)
    window.show()
    
    # 启动应用主循环
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
    