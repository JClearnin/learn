from PyQt5.QtWidgets import (QMainWindow, QPushButton, QLabel, QTextEdit, 
                            QVBoxLayout, QHBoxLayout, QFrame, QGroupBox)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QFont
from business_logic import MessageType

class UIApp(QMainWindow):
    """PyQt5 UI应用类"""
    def __init__(self, queue, business_logic):
        super().__init__()
        self.queue = queue  # 通信队列
        self.business = business_logic  # 业务逻辑实例
        
        # 设置窗口属性
        self.setWindowTitle("PyQt与业务逻辑通信示例")
        self.setGeometry(100, 100, 600, 500)
        
        # 初始化UI
        self._init_ui()
        
        # 设置定时器处理队列消息
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._process_queue)
        self.timer.start(100)  # 每100ms检查一次队列
    
    def _init_ui(self):
        """初始化UI组件"""
        # 创建主布局
        main_layout = QVBoxLayout()
        
        # 1. 控制按钮区域
        control_frame = QFrame()
        control_layout = QHBoxLayout(control_frame)
        
        self.start_btn = QPushButton("启动业务程序")
        self.start_btn.clicked.connect(self._on_start_clicked)
        control_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("停止业务程序")
        self.stop_btn.clicked.connect(self._on_stop_clicked)
        self.stop_btn.setEnabled(False)  # 初始禁用
        control_layout.addWidget(self.stop_btn)
        
        main_layout.addWidget(control_frame)
        
        # 2. 状态显示区域
        status_frame = QFrame()
        status_layout = QVBoxLayout(status_frame)
        
        self.status_label = QLabel("请启动业务程序")
        self.status_label.setStyleSheet("color: blue; font-weight: bold;")
        status_layout.addWidget(self.status_label)
        
        main_layout.addWidget(status_frame)
        
        # 3. 数据显示区域
        data_group = QGroupBox("最新数据")
        data_layout = QVBoxLayout(data_group)
        
        self.data_label = QLabel("等待数据...")
        self.data_label.setFont(QFont("Arial", 24))
        self.data_label.setAlignment(Qt.AlignCenter)
        data_layout.addWidget(self.data_label)
        
        main_layout.addWidget(data_group)
        
        # 4. 日志显示区域
        log_group = QGroupBox("日志")
        log_layout = QVBoxLayout(log_group)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)  # 只读
        log_layout.addWidget(self.log_text)
        
        main_layout.addWidget(log_group, 1)  # 占更多空间
        
        # 设置中心部件
        central_widget = QFrame()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)
    
    def _on_start_clicked(self):
        """启动业务程序按钮点击事件"""
        self.business.start_work()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self._add_log("启动业务程序")
    
    def _on_stop_clicked(self):
        """停止业务程序按钮点击事件"""
        self.business.stop_work()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._add_log("停止业务程序")
    
    def _add_log(self, message):
        """添加日志信息"""
        from datetime import datetime
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")
        # 滚动到底部
        self.log_text.moveCursor(self.log_text.textCursor().End)
    
    def _process_queue(self):
        """处理队列中的消息"""
        # 处理队列中所有可用消息
        while not self.queue.empty():
            try:
                message = self.queue.get_nowait()
                
                # 根据消息类型处理
                if message['type'] == MessageType.STATUS_UPDATE:
                    self.status_label.setText(message['data'])
                    self._add_log(message['data'])
                elif message['type'] == MessageType.DATA_UPDATE:
                    data = message['data']
                    self.data_label.setText(f"{data['value']}")
                    self._add_log(f"收到数据: {data['value']} ({data['timestamp']})")
                elif message['type'] == MessageType.ERROR:
                    self._add_log(f"错误: {message['data']}")
                elif message['type'] == MessageType.FINISHED:
                    self._add_log(message['data'])
            
            except Exception as e:
                self._add_log(f"处理消息出错: {str(e)}")
                break
    