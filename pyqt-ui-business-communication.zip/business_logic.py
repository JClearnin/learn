import threading
import time
import random
from datetime import datetime

# 消息类型枚举
class MessageType:
    STATUS_UPDATE = 1  # 状态更新
    DATA_UPDATE = 2    # 数据更新
    ERROR = 3          # 错误信息
    FINISHED = 4       # 任务完成

class BusinessLogic:
    """业务逻辑类，处理后台任务并通过队列发送消息"""
    def __init__(self, queue):
        self.queue = queue  # 通信队列
        self.running = False  # 运行状态标志
        self.thread = None  # 业务线程
        
    def start_work(self):
        """启动业务处理线程"""
        if not self.running:
            self.running = True
            # 创建并启动线程
            self.thread = threading.Thread(target=self._work_loop, daemon=True)
            self.thread.start()
            # 发送状态更新
            self._send_message(
                MessageType.STATUS_UPDATE, 
                "业务程序已启动"
            )
    
    def stop_work(self):
        """停止业务处理线程"""
        if self.running:
            self.running = False
            if self.thread and self.thread.is_alive():
                self.thread.join()  # 等待线程结束
            self._send_message(
                MessageType.STATUS_UPDATE, 
                "业务程序已停止"
            )
    
    def _work_loop(self):
        """业务处理主循环"""
        count = 0
        while self.running:
            # 模拟业务处理：生成随机整数
            data = random.randint(1, 100)
            
            # 发送数据更新消息
            self._send_message(
                MessageType.DATA_UPDATE, 
                {
                    'value': data,
                    'timestamp': datetime.now().strftime("%H:%M:%S")
                }
            )
            
            count += 1
            # 每5次迭代发送一次状态更新
            if count % 5 == 0:
                self._send_message(
                    MessageType.STATUS_UPDATE, 
                    f"已处理 {count} 条数据"
                )
            
            # 模拟处理耗时
            time.sleep(1)
        
        # 发送任务完成消息
        self._send_message(
            MessageType.FINISHED, 
            f"总计处理 {count} 条数据"
        )
    
    def _send_message(self, msg_type, data):
        """向队列发送消息"""
        try:
            self.queue.put({
                'type': msg_type,
                'data': data
            }, block=False)  # 非阻塞方式放入队列
        except Exception as e:
            print(f"发送消息失败: {str(e)}")
    